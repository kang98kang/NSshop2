/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["oopy.lazyrockets.com"],
  },
};

module.exports = nextConfig;
